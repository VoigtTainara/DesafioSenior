package com.senior.avaliacao.qs1;

import java.util.List;

public interface INotaFiscal {
	List<Double> geraParcelas(int nrParcelas, double valorTotal);
}
