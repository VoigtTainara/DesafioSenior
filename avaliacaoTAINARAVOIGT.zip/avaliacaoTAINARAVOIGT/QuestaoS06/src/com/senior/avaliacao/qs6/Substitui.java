package com.senior.avaliacao.qs6;

public class Substitui implements ISubstitui{
	
	public static void main(String[] args) {
		 new Substitui().substituir("O rato roeu a roupa do rei de roma", "ro", "teste");
	}

	 public String substituir(final String literal, final String velho, final String novo){
	        System.out.println("Entrada: " + literal);
	        System.out.println("Substituindo: " + velho);
	        System.out.println("Por: " + novo);
	        String retorno = literal;

	        while (instr(retorno, velho) > -1) {
	            retorno = substituirPos(retorno, instr(retorno, velho), novo, velho);
	        }
	        System.out.println("Resultado: " + retorno);

	        return "";

	    }

	    private int instr(final String str, final String cont) {
	        char[] strC = str.toCharArray();
	        char[] contC = cont.toCharArray();

	        int initPos = -1;
	        int contadorPosic = 0;
	        
	        //percorre a string e verifica se h� ocorr�ncia da substring na string
	        for (int i = 0; i < strC.length; i++) {
	            if (strC[i] == contC[0] && initPos == -1) {
	                initPos = i;
	                contadorPosic++;
	            } else if (initPos > -1 && strC[i] == contC[contadorPosic]) {
	                contadorPosic++;
	            } else if (initPos > -1 && strC[i] != contC[contadorPosic]) {
	                initPos = -1;
	                contadorPosic = 0;
	            }
	            //caso a substring inteira tenha sido encontrada na string, retorna a posi��o em que se 
	            //encontra o primeiro caracter da substring na string
	            if (contadorPosic == contC.length) {
	                return initPos;
	            }
	        }
	        return initPos + cont.length() > str.length() ? -1 : initPos;
	    }

	    private String substituirPos(final String str, final int posInit, final String conteudo, final String old) {
	        String novaString;
	        //constr�i a nova string, substituindo as ocorr�ncias da substring na string pelo novo conte�do.
	        novaString = substr(str, 0, posInit)
	                + conteudo
	                + (substr(str, posInit + old.toCharArray().length > str.toCharArray().length ? str.toCharArray().length : posInit + old.toCharArray().length, str.toCharArray().length));
	        return novaString;
	    }

	    private String substr(final String str, final int posInit, final int posFinal) {
	        char[] value = str.toCharArray();
	        if (posInit < 0) {
	            throw new StringIndexOutOfBoundsException(posInit);
	        }
	        int subLen = posFinal - posInit;

	        return ((posInit == 0) && (posFinal == value.length)) ? str
	                : new String(value, posInit, subLen);
	    }

	}