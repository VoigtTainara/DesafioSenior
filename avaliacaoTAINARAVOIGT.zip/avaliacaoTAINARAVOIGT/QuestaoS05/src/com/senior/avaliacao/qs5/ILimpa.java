package com.senior.avaliacao.qs5;

public interface ILimpa {
	String limpar(String string, String substring);
}
