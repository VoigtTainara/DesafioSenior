package com.senior.avaliacao.qs3;

public interface IValidaProtocolo {
	boolean validaProtocolo(String protocolo);
}
