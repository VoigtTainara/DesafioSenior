package com.senior.avaliacao.qs3;

import java.util.Scanner;

public class ValidaProtocolo implements IValidaProtocolo{

	static Scanner s = new Scanner(System.in);
	static String protocolo="";
	static boolean validar=false;
	
	public static void main(String[] args) {
		System.out.println("informe um protocolo");
		protocolo = s.nextLine();
	    validar = new ValidaProtocolo().validaProtocolo(protocolo);
	}	
	
	@Override
	public boolean validaProtocolo(String protocolo) {
		int num=0, novoDigito; 
		int fatorMul = 2, res=0, aux;
		char[] anum = new char[8];
		int tamProtocolo = protocolo.length();
		
		//converte o protocolo de 6 d�gitos, de string para array de char
		for (int u=0; u<tamProtocolo;u++) {
			anum[u] = protocolo.charAt(u);
		}

		//repete o for duas vezes, uma vez que o protocolo deve ter 8 dig�tos
		for (int vezes = 0; vezes < 2; vezes++) {
			//percorre cada dig�to do n�mero na ordem inversa
			for (int i = tamProtocolo - 1; i >= 0; i--) {
				
				num = Integer.parseInt(String.valueOf(anum[i]));
				
				// multiplica o n�mero pelo fator
				aux = num*fatorMul;
				
				// acumula o resultado da multiplica��o
				res = res + aux;

				//e aumenta o fator
				fatorMul++;
			}
			
			//faz o c�lculo de multiplica��o e resto de divis�o
			novoDigito = (res*10)%11;
			
			if (novoDigito == 10){
				novoDigito=0;
			}
			
			// converte o d�gito para char; obs: 48 � o c�digo ASCII de "0";
			// 65 � o c�digo ASCII de "A"
			char novo= (char) (novoDigito + 48);
			anum[tamProtocolo] = novo;
					
			// aumenta o tamanho do protocolo
			tamProtocolo++;
			
			//reinicia o fator de multiplica��o
			fatorMul = 2;
		}
		System.out.println(anum);
		return true;
	}
}


