package com.senior.avaliacao.qs7;

import java.util.List;

public interface IMaquina {
	List<Troco> montarTroco(Double troco);
}
